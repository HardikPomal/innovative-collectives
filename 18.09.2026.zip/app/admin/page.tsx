import Link from "next/link";
import {
    TrendingUp,
    ShoppingBag,
    Package,
    CreditCard,
    ArrowUpRight,
    Plus,
    AlertTriangle,
    Users,
    Settings,
} from "lucide-react";
import Button from "@/components/ui/Button";
import { formatPrice } from "@/lib/utils";
import { products, categories } from "@/data/products";
import { initialMockOrders } from "@/data/mockOrders";
import { getAdminMetrics } from "@/data/mockAdmin";

function getStatusStyle(status: string) {
    switch (status) {
        case "Delivered":
            return "text-emerald-600 font-medium";
        case "In Transit":
            return "text-navy font-medium";
        case "Processing":
            return "text-gold font-medium";
        case "Cancelled":
            return "text-red-600 font-medium";
        default:
            return "text-navy/60";
    }
}

export default function AdminDashboardPage() {
    const metrics = getAdminMetrics();

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            {/* Page Title */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-heading text-navy">
                        Dashboard
                    </h1>
                    <p className="text-navy/70 mt-1">
                        Overview of platform performance and recent activity.
                    </p>
                </div>
                <Button
                    href="/admin/products/new"
                    variant="secondary"
                    icon={<Plus size={16} />}
                >
                    Add Product
                </Button>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {[
                    {
                        label: "Total Revenue",
                        value: formatPrice(metrics.totalRevenue),
                        sub: "+18.4% vs last month",
                        icon: TrendingUp,
                    },
                    {
                        label: "Total Orders",
                        value: metrics.totalOrdersCount.toLocaleString(),
                        sub: "12 pending dispatch",
                        icon: ShoppingBag,
                    },
                    {
                        label: "Products",
                        value: `${metrics.totalProductsCount} Items`,
                        sub: `${metrics.inStockProductsCount} in stock`,
                        icon: Package,
                    },
                    {
                        label: "Avg. Order Value",
                        value: formatPrice(metrics.averageOrderValue),
                        sub: "+6.2% average basket",
                        icon: CreditCard,
                    },
                ].map((card) => {
                    const Icon = card.icon;
                    return (
                        <div
                            key={card.label}
                            className="bg-navy p-6 rounded-2xl shadow-sm"
                        >
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-xs uppercase tracking-wider text-cream/60 font-semibold">
                                    {card.label}
                                </span>
                                <Icon size={18} className="text-gold" />
                            </div>
                            <p className="text-2xl text-cream font-heading leading-tight">
                                {card.value}
                            </p>
                            <p className="text-xs mt-2 text-cream/70">
                                {card.sub}
                            </p>
                        </div>
                    );
                })}
            </div>

            {/* Bottom Grid: Recent Orders + Category Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Recent Orders Table */}
                <div className="lg:col-span-2 bg-ivory border border-navy/10 shadow-sm rounded-2xl overflow-hidden">
                    <div className="flex items-center justify-between px-6 py-5 border-b border-navy/10">
                        <h2 className="text-lg font-heading text-navy">
                            Recent Orders
                        </h2>
                        <Link
                            href="/admin/orders"
                            className="text-xs text-navy/70 hover:text-navy transition-colors flex items-center gap-1 uppercase tracking-widest font-semibold"
                        >
                            View All <ArrowUpRight size={14} />
                        </Link>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead>
                                <tr className="bg-cream text-navy">
                                    {["Order", "Customer", "Date", "Status", "Total"].map((h) => (
                                        <th
                                            key={h}
                                            className={`py-3 px-6 font-heading uppercase tracking-wider text-xs ${h === "Total" ? "text-right" : ""}`}
                                        >
                                            {h}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {initialMockOrders.map((order) => (
                                    <tr
                                        key={order.id}
                                        className="border-b border-navy/5 hover:bg-cream/50 transition-colors text-navy/80"
                                    >
                                        <td className="py-4 px-6 font-mono text-navy font-medium">
                                            <Link
                                                href={`/admin/orders/${order.id}`}
                                                className="hover:text-gold transition-colors"
                                            >
                                                {order.orderNumber}
                                            </Link>
                                        </td>
                                        <td className="py-4 px-6">
                                            {order.shippingAddress.fullName}
                                        </td>
                                        <td className="py-4 px-6 text-navy/60">
                                            {order.date}
                                        </td>
                                        <td className="py-4 px-6">
                                            <span className={`text-xs uppercase tracking-wider ${getStatusStyle(order.status)}`}>
                                                {order.status}
                                            </span>
                                        </td>
                                        <td className="py-4 px-6 text-right font-medium text-navy">
                                            {formatPrice(order.total)}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="space-y-6">
                    {/* Category Breakdown */}
                    <div className="bg-ivory border border-navy/10 shadow-sm p-6 rounded-2xl">
                        <h2 className="text-lg font-heading text-navy mb-5">
                            Products by Category
                        </h2>
                        <div className="space-y-4">
                            {categories.map((cat) => {
                                const count = products.filter((p) => p.category === cat.slug).length;
                                const pct = Math.round((count / products.length) * 100);
                                return (
                                    <div key={cat.slug}>
                                        <div className="flex justify-between text-sm mb-1.5">
                                            <span className="text-navy">{cat.name}</span>
                                            <span className="text-navy/60 font-mono text-xs">{count} items</span>
                                        </div>
                                        <div className="h-1 bg-cream overflow-hidden rounded-full">
                                            <div
                                                className="h-full bg-gold"
                                                style={{ width: `${Math.min(pct * 2.5, 100)}%` }}
                                            />
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>


                </div>
            </div>
        </div>
    );
}
